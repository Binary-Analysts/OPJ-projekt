import pandas as pd


train_df = pd.read_excel("train.xlsx")
val_df = pd.read_excel("validation.xlsx")
test_df = pd.read_excel("test.xlsx")


def clean_labels(df):
    df['label_final'] = df['label_final'].str.lower().str.strip()
    return df

train_df = clean_labels(train_df)
val_df = clean_labels(val_df)
test_df = clean_labels(test_df)


def clean_text(text):
    text = str(text).lower()
    text = ''.join([c for c in text if c.isalnum() or c.isspace()])
    return text.split()

for df in [train_df, val_df, test_df]:
    df['word_count'] = df['text'].apply(lambda x: len(clean_text(x)))


labels = ['positive', 'negative', 'neutral', 'sarcasm', 'mixed']

def print_label_distribution(name, df):
    print(f"\n{name} label distribution")
    dist = df['label_final'].value_counts().reindex(labels, fill_value=0)
    for label, count in dist.items():
        print(f"{label}: {count}")

print_label_distribution("Train", train_df)
print_label_distribution("Validation", val_df)
print_label_distribution("Test", test_df)


def sentence_stats(name, df):
    avg = df['word_count'].mean()
    min_len = df['word_count'].min()
    max_len = df['word_count'].max()

    shortest = df.loc[df['word_count'].idxmin(), 'text']
    longest = df.loc[df['word_count'].idxmax(), 'text']

    print(f"\n{name} words")
    print(f"Average words: {avg:.2f}")
    print(f"Shortest ({min_len} words): {shortest}")
    print(f"Longest ({max_len} words): {longest}")

sentence_stats("Train", train_df)
sentence_stats("Validation", val_df)
sentence_stats("Test", test_df)


