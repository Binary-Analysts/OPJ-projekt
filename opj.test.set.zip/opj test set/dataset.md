Train label distribution
positive: 419
negative: 217
neutral: 136
sarcasm: 14
mixed: 29

Validation label distribution
positive: 1449
negative: 612
neutral: 415
sarcasm: 42
mixed: 80

Test label distribution
positive: 135
negative: 369
neutral: 114
sarcasm: 6
mixed: 25

Train words
Average words: 12.73
Shortest (1 words): Grozno!
Longest (98 words): zbog povišenih androgena me godinu dana kljukala tabletama a da me nijednom nije poslala pregledati krv, slucajno na sistematskom mi otkrili tesko ostecenje jetre; od tableta sam imala niz nus pojava(danas znam da sam mogla odapet), placuci sam je molila da mi promjeni terapiju,ali me frknila van da ne može nego se trebam naviknutii poslala me mojoj dr da uzmem nesto za smirenje, naplacivala mi ultrazvucne preglede svaki put, za pregled prvo moram izac s posla kako bi se narucila, pa kad sam narucena opet izac s posla i cekat red satima i onda jos platim ultrazvuke papu

Validation words
Average words: 14.30
Shortest (0 words): :-)
Longest (88 words): Ono što sam čuo, nisam doživio, jest da je nekoga "izbacila iz ordinacije na popravni" (moja konstrukcija, ne onoga od koga sam ju čuo) jer dijete nije u ordinaciju ušlo skinuto za pregled (čini mi se da je pravilo u donjem rublju) – isto smatram prihvatljivim jer iz iskustva znam koliko je to lakše napraviti u zagrijanoj čekaonici gdje za dijete ne postoji stres kute i instrumenata – i zato jer je to pravilo s kojim se slažem i koje jasno piše na zidu čekaonice, točno iznad prostora za skidanje

Test words
Average words: 15.86
Shortest (0 words): ❤️
Longest (82 words): i nije to sve, kada sam nakon tri mjeseca došla po još neke papire , gospođa kod koje su te papire ostavili mi je rekla, joj zašto je odmah niste tužili , jedva čekamo da je se riješimo, ali svaka tužba stane na višem sudu gdje dotičnoj radi sestra-sestrična (nisam zapamtila) epilog- moja mama umjesto da mirno proživi još tih par godina svog života , bori se sa konstantnim urino infektima (nikada ih do tada nije imala), priraslicama u abdomenu i bolovima u trbušnoj šupljini